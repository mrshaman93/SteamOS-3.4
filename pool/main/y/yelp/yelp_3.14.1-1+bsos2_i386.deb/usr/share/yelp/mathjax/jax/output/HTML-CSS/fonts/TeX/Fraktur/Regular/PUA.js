/*
 *  /MathJax/jax/output/HTML-CSS/fonts/TeX/Fraktur/Regular/PUA.js
 *  
 *  Copyright (c) 2012 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Hub.Insert(MathJax.OutputJax["HTML-CSS"].FONTDATA.FONTS.MathJax_Fraktur,{58112:[683,32,497,75,430],58113:[616,30,498,35,432],58114:[680,215,333,29,339],58115:[679,224,329,28,318],58116:[471,214,503,52,449],58117:[686,20,333,26,315],58118:[577,21,334,29,347],58119:[475,22,501,10,514]});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].fontDir+"/Fraktur/Regular/PUA.js");

