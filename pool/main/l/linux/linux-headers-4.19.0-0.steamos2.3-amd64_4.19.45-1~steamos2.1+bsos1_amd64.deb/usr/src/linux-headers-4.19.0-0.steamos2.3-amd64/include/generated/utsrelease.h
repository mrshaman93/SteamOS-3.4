#define UTS_RELEASE "4.19.0-0.steamos2.3-amd64"
